Blockly.Msg.MAX30101_HEART_RATE = "Heart Rate (bpm)";
Blockly.Msg.MAX30101_RAW_DATA = "Heart Rate Sensor get raw data";
Blockly.Msg.MAX30101_RED = "Red";
Blockly.Msg.MAX30101_IR = "IR";

