#ifndef __IRreceiver_H__
#define __IRreceiver_H__

#include "driver.h"
#include "device.h"
#include "i2c-dev.h"
#include <string.h>

//typedef void(*EventCallback)(void);

class IRreceiver : public Device
{
private:
	enum
	{
		s_detect,
		s_read,
		s_error,
		s_wait
	} state;
	TickType_t tickcnt, polling_tickcnt;
	I2CDev *i2c;
	//EventCallback onPessIRCallback[2] = {NULL, NULL};
    uint8_t reg ;
	int buttonIR = 0;
	int Data3 = NULL;
	int press[2];
	int p;
	bool dataUpdateFlag = false;
	bool previous = false;

public:
	// constructor
	IRreceiver();
	
	// override
	void init(void);
	void process(Driver *drv);
	int prop_count(void);
	bool prop_name(int index, char *name);
	bool prop_unit(int index, char *unit);
	bool prop_attr(int index, char *attr);
	bool prop_read(int index, char *value);
	bool prop_write(int index, char *value);
	
	// method
	int IRpressed(uint8_t ArrayButton);
    //int IRStatus(void);
	int IRReader(int SL);
};

#endif