#ifndef __compass_CPP__
#define __compass_CPP__

#include "compass.h"

compass::compass(int bus_ch, int dev_addr) {
	channel = bus_ch;
	address = dev_addr;
	polling_ms = 100;
}

void compass::init(void) {
	// clear error flag
	error = true;
	// set initialized flag
	initialized = false;

	// Reset speed of I2C
	i2c_config_t conf;

	conf.mode = I2C_MODE_MASTER;
	conf.sda_io_num = CHAIN_SDA_GPIO;
	conf.sda_pullup_en = GPIO_PULLUP_ENABLE;
	conf.scl_io_num = CHAIN_SCL_GPIO;
	conf.scl_pullup_en = GPIO_PULLUP_ENABLE;
	conf.master.clk_speed = 1E3;

	i2c_param_config(I2C_NUM_1, &conf);

	// Set new timeout of i2c
	i2c_set_timeout(I2C_NUM_1, 20000);

	setM = true;
	
	state = s_detect;
}

int compass::prop_count(void) {
	// not supported
	return 0;
}

bool compass::prop_name(int index, char *name) {
	// not supported
	return false;
}

bool compass::prop_unit(int index, char *unit) {
	// not supported
	return false;
}

bool compass::prop_attr(int index, char *attr) {
	// not supported
	return false;
}

bool compass::prop_read(int index, char *value) {
	// not supported
	return false;
}

bool compass::prop_write(int index, char *value) {
	// not supported
	return false;
}
// --------------------------------------

void compass::process(Driver *drv) {
  i2c = (I2CDev *)drv;
	switch (state) {
		case s_detect:
			// detect i2c device
			if (i2c->detect(channel, address) == ESP_OK) {
				state = s_setup;
				
			} else {
				state = s_error;
			}
			break;
    case s_setup: {
      if (setM){
        uint8_t buffer[8] = {MMC56X3_CTRL1_REG, 0x80, MMC56X3_CTRL0_REG, 0x08, MMC56X3_CTRL0_REG, 0x10, MMC56X3_CTRL2_REG, 0x00};
        for (int i = 0 ; i < 8 ; i++ ) {
          if (i2c->write(channel, address, &buffer[i], 2) != ESP_OK ){
            state = s_error;
            break;
          }
        }

        uint8_t buffer2[8] = {0x1A, 0x32, 0x1D, 0x00, MMC56X3_CTRL0_REG, 0x80, MMC56X3_CTRL2_REG, 0x10};
        for (int i = 0 ; i < 8 ; i++ ) {
          if (i2c->write(channel, address, &buffer2[i], 2) != ESP_OK){
            state = s_error;
            break;
          }
        }
        setM = false;
        state = s_read;
      }
    }
		case s_read: {
			if (is_tickcnt_elapsed(tickcnt, polling_ms)) {
				tickcnt = get_tickcnt();
        
				getEvent();
				float declinationAngle = 0.0137;
				heading = atan2(yy,xx);
  				heading += declinationAngle;
  				if (heading < 0){heading += 2 * M_PI;}
  				if (heading > 2 * M_PI){heading -= 2 * M_PI;}
  				headingDegrees = heading * 180 / M_PI;
				
				
			}
		}
		case s_wait:
			if (error) {
				// wait polling_ms timeout
				if (is_tickcnt_elapsed(tickcnt, polling_ms)) {
					state = s_detect;
				}
			}
			break;

		case s_error:			
			// set error flag
			headingDegrees = 400;
			setM = true;
			error = true;
			// clear initialized flag
			initialized = false;
			// get current tickcnt
			tickcnt = get_tickcnt();
			// goto wait and retry with detect state
			state = s_wait;
			break;

	}
}

// Method
uint16_t compass::getdegree() {
	return headingDegrees;
}


void compass::writeReg(uint8_t reg, uint8_t value) {
  i2c->write(channel, address, &reg, 1);
  //vTaskDelay(10);
  i2c->write(channel, address, &value, 1);
}

bool compass::write21(uint8_t *buffer, size_t len, bool stop, const uint8_t *prefix_buffer, size_t prefix_len) {
	
	if ((prefix_len != 0) && (prefix_buffer != NULL)) {
    
    if (i2c->write(channel, address, 0, 1) != prefix_len) {
      //Serial.println(F("\tI2CDevice failed to write"));
      return false;
    }
  }

  // Write the data itself, chunkify if needed
  size_t bufferSize = 250;
  if (bufferSize >= len) {
    // can just write
    //Serial.println(F("\tbufferSize >= len write21_1"));
    size_t pos = 0;
    uint8_t write_buffer[bufferSize];
    while (pos < len) {
      size_t write_len = len - pos > bufferSize ? bufferSize : len - pos;
      for (size_t i = 0; i < write_len; i++){
        write_buffer[i] = buffer[pos++];
        //Wire.write(write_buffer[i]);
		i2c->write(channel, address, &write_buffer[i], 1);
      }
    } 
  }/**/else {
    // must chunkify
    //Serial.println(F("\tbufferSize >= len_else write21_1"));
    size_t pos = 0;
    uint8_t write_buffer[bufferSize];
    while (pos < len) {
      size_t write_len = len - pos > bufferSize ? bufferSize : len - pos;
      for (size_t i = 0; i < write_len; i++){
		write_buffer[i] = buffer[pos++];
		i2c->write(channel, address, &write_buffer[i], 1);
	  }
    }
  }
  return true;
}



bool compass::_read(uint8_t *buffer, size_t len, bool stop) {

	uint8_t data[9];
	if (i2c->read(channel, address, NULL, 0, data, 9) != ESP_OK) {
		//state = s_error;
		return false;
	}

  	for (uint16_t i = 0; i < len; i++) {
    	buffer[i] = data[i];
  	}

  	return true;
}

bool compass::read21(uint8_t *buffer, size_t len, bool stop) {
  size_t bufferSize = 250;
  if (bufferSize >= len) {
    // can just read
    return _read(buffer, len, stop);
  } else {
    // must chunkify
    size_t pos = 0;
    uint8_t read_buffer[bufferSize];
    while (pos < len) {
      size_t read_len = len - pos > bufferSize ? bufferSize : len - pos;
      if (!_read(read_buffer, read_len, false)) {
        return false;
      }
      for (size_t i = 0; i < read_len; i++)
        buffer[pos++] = read_buffer[i];
    }
    return true;
  }
}
bool compass::write2read(uint8_t *write_buffer, size_t write_len, uint8_t *read_buffer , size_t read_len , bool stop) {
  
  /**/
  if (!write21(write_buffer, write_len, stop)) {
    return false;
  }

  return read21(read_buffer, read_len);
}
bool compass::getEvent() {
  uint8_t buffer[9];
  buffer[0] = MMC56X3_OUT_X_L;

  // read 8 bytes!
  if (!write2read(buffer, 1, buffer, 9)) {
    return false;
  }

  x = (uint32_t)buffer[0] << 12 | (uint32_t)buffer[1] << 4 | (uint32_t)buffer[6] >> 4;
  y = (uint32_t)buffer[2] << 12 | (uint32_t)buffer[3] << 4 | (uint32_t)buffer[7] >> 4;
  z = (uint32_t)buffer[4] << 12 | (uint32_t)buffer[5] << 4 | (uint32_t)buffer[8] >> 4;
  // fix center offsets
  x -= (uint32_t)1 << 19;
  y -= (uint32_t)1 << 19;
  z -= (uint32_t)1 << 19;

  xx = (float)x * 0.00625; // scale to uT by LSB in datasheet
  yy = (float)y * 0.00625;
  zz = (float)z * 0.00625;

  return true;
}

#endif