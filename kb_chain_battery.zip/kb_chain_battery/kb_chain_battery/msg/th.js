Blockly.Msg.kb_chain_battery_TEXT_TITLE   = "อ่านค่าเเบตเตอรรี่";
Blockly.Msg.kb_chain_battery_TEXT_TOOLTIP = "อ่านค่าเเบตเตอรรี่คงเหลือ";
Blockly.Msg.kb_chain_battery_TEXT_HELPURL = "kb_chain_battery HELPURL";
