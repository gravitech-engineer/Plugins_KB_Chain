Blockly.Msg.write_led_TEXT_TITLE   = "กำหนดเเอลอีดี";
Blockly.Msg.write_led_TEXT_1   = "ชื่อ";
Blockly.Msg.write_led_TEXT_2   = "สถานะ";
Blockly.Msg.write_led_TEXT_TOOLTIP = "กำหนดสถานะเเอลอีดี";
Blockly.Msg.write_led_TEXT_HELPURL = "";
