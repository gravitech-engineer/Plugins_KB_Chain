Blockly.Msg.OLED_128X64_I2C_TITLE = "จอโอแอลอีดี 128x64 แบบไอสแควร์ซี";

Blockly.Msg.OLED_128X64_I2C_CLR_TITLE = "ล้างหน้าจอ";
Blockly.Msg.OLED_128X64_I2C_CLR_TOOLTIP = "ล้างหน้าจอแสดงผลโอแอลอีดี 128x64 แบบไอสแควร์ซี";
Blockly.Msg.OLED_128X64_I2C_CLR_HELPURL = "";

Blockly.Msg.OLED_128X64_I2C_PRINT_TITLE = "พิมพ์";
Blockly.Msg.OLED_128X64_I2C_PRINT_TOOLTIP = "พิมพ์บนจอแสดงผลโอแอลอีดี 128x64 แบบไอสแควร์ซี ที่ตำแหน่ง (คอลัมน์, แถว)";
Blockly.Msg.OLED_128X64_I2C_PRINT_HELPURL = "";

Blockly.Msg.OLED_128X64_I2C_PRINT_PREC_TITLE = "พิมพ์ตัวเลข";
Blockly.Msg.OLED_128X64_I2C_PRINT_PREC_TOOLTIP = "พิมพ์ตัวเลขบนจอแสดงผลโอแอลอีดี 128x64 แบบไอสแควร์ซี ที่ตำแหน่ง (คอลัมน์, แถว) แบบกำหนดจำนวนทศนิยม";
Blockly.Msg.OLED_128X64_I2C_PRINT_PREC_HELPURL = "";

Blockly.Msg.OLED_128X64_I2C_PRINT_BIG_TITLE = "พิมพ์ตัวใหญ่";
Blockly.Msg.OLED_128X64_I2C_PRINT_BIG_TOOLTIP = "พิมพ์์ตัวใหญ่บนจอแสดงผลโอแอลอีดี 128x64 แบบไอสแควร์ซี ที่ตำแหน่ง (คอลัมน์, แถว)";
Blockly.Msg.OLED_128X64_I2C_PRINT_BIG_HELPURL = "";

Blockly.Msg.OLED_128X64_I2C_PRINT_BIG_PREC_TITLE = "พิมพ์ตัวเลข์ตัวใหญ่";
Blockly.Msg.OLED_128X64_I2C_PRINT_BIG_PREC_TOOLTIP = "พิมพ์ตัวเลข์ตัวใหญ่บนจอแสดงผลโอแอลอีดี 128x64 แบบไอสแควร์ซี ที่ตำแหน่ง (คอลัมน์, แถว) แบบกำหนดจำนวนทศนิยม";
Blockly.Msg.OLED_128X64_I2C_PRINT_BIG_PREC_HELPURL = "";

Blockly.Msg.PRECISION_TITLE = "ทศนิยม";
