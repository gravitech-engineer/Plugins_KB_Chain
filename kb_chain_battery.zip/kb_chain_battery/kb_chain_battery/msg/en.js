Blockly.Msg.kb_chain_battery_TEXT_TITLE   = "Read Battery";
Blockly.Msg.kb_chain_battery_TEXT_TOOLTIP = "Read Battery Remaining";
Blockly.Msg.kb_chain_battery_TEXT_HELPURL = "";
