#ifndef __compass_H__
#define __compass_H__

#include "driver.h"
#include "device.h"
#include "i2c-dev.h"
#include "kidbright32.h"
#include "math.h"

#define	  MMC56X3_PRODUCT_ID  0x39
#define	  MMC56X3_CTRL0_REG  0x1B
#define	  MMC56X3_CTRL1_REG  0x1C
#define	  MMC56X3_CTRL2_REG  0x1D
#define	  MMC56X3_STATUS_REG  0x18
#define	  MMC56X3_OUT_TEMP  0x09
#define	  MMC56X3_OUT_X_L  0x00
#define	  MMC5603_ODR_REG  0x1A

class compass : public Device {
	private:		
		enum {
			s_detect,
			s_read,
			s_setup,
			s_wait,
			s_error
		} state;
		TickType_t tickcnt, polling_tickcnt;
		

		

		I2CDev *i2c;
        uint8_t reg = 0x00;
		uint16_t _odr_cache = 0;
		uint8_t _ctrl2_cache = 0;
		int32_t x; ///< x-axis raw data
		int32_t y; ///< y-axis raw data
		int32_t z; ///< z-axis raw data
		float xx;
		float yy;
		float zz;
		float headingDegrees;
		float heading = 0;
		bool setM = false;
		uint32_t j = 0;

		void writeReg (uint8_t reg, uint8_t value);
		bool write21(uint8_t *buffer, size_t len, bool stop, const uint8_t *prefix_buffer = NULL, size_t prefix_len = 0);
		bool read21(uint8_t *buffer, size_t len, bool stop = true);
		bool _read(uint8_t *buffer, size_t len, bool stop);
		bool write2read(uint8_t *write_buffer, size_t write_len, uint8_t *read_buffer , size_t read_len , bool stop = false);

	public:
		// constructor
		compass(int bus_ch, int dev_addr) ;
		
		// override
		void init(void);
		void process(Driver *drv);
		int prop_count(void);
		bool prop_name(int index, char *name);
		bool prop_unit(int index, char *unit);
		bool prop_attr(int index, char *attr);
		bool prop_read(int index, char *value);
		bool prop_write(int index, char *value);
		
		// method
		uint16_t getdegree();
		bool getEvent();

};

#endif