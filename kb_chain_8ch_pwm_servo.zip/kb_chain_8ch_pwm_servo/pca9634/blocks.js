Blockly.Blocks['PCA9634_LED_Brightness'] = {
    init: function () {
        this.appendValueInput("Brightness")
            .setCheck('Number')
            .appendField(Blockly.Msg.kb_chain_pca9634_set_brightness_1)
            .appendField(new Blockly.FieldDropdown([["0x01", "1"], ["0x04", "4"],["0x05", "5"],["0x70", "112"]]), "addr")
            .appendField(Blockly.Msg.kb_chain_pca9634_set_brightness_2)
            .appendField(new Blockly.FieldDropdown([["1", "7"], ["2", "6"], ["3", "5"], ["4", "4"], ["5", "3"], ["6", "2"], ["7", "1"], ["8", "0"]]), "pin")
            .appendField(Blockly.Msg.kb_chain_pca9634_set_brightness_3);
            // .appendField(new Blockly.FieldNumber(0,0,255), "brightness");
        this.setPreviousStatement(true, null);
        this.setNextStatement(true, null);
        this.setColour(230);
        this.setTooltip(Blockly.Msg.kb_chain_pca9634_set_brightness_tooltip);
        this.setHelpUrl("");
    },
    xmlToolbox: function() {
		return $(document.createElement('block')).attr({
			type: 'PCA9634_LED_Brightness'
		}).append('\
		   <value name="Brightness">\
			   <shadow type="PCA9634_LED_Brightness.Brightness">\
			   </shadow>\
		   </value>'
	   );
    }
};

Blockly.Blocks["PCA9634_LED_Brightness.Brightness"] = {
	init: function() {
		this.appendDummyInput()
			.appendField(new Blockly.FieldNumber(255, 0, 255), 'VALUE');
		this.setOutput(true, 'Number');
		this.setPreviousStatement(false);
		this.setNextStatement(false);
		this.setColour(math_colour);
	this.setTooltip("");
	this.setHelpUrl("");
	},
	// custom xmlToolboxcolumn
	xmlToolbox: function() {
		return null; // hidden block
	}
};

Blockly.Blocks['PCA9634_LED_State'] = {
    init: function () {
        this.appendDummyInput()
            .appendField(Blockly.Msg.kb_chain_pca9634_set_state_1)
            .appendField(new Blockly.FieldDropdown([["0x01", "1"], ["0x04", "4"],["0x05", "5"],["0x70", "112"]]), "addr")
            .appendField(Blockly.Msg.kb_chain_pca9634_set_state_2)
            .appendField(new Blockly.FieldDropdown([["1", "7"], ["2", "6"], ["3", "5"], ["4", "4"], ["5", "3"], ["6", "2"], ["7", "1"], ["8", "0"]]), "pin")
            .appendField(Blockly.Msg.kb_chain_pca9634_set_state_3)
            .appendField(new Blockly.FieldDropdown([["ON", "1"], ["OFF", "0"]]), "state");
        this.setPreviousStatement(true, null);
        this.setNextStatement(true, null);
        this.setColour(230);
        this.setTooltip(Blockly.Msg.kb_chain_pca9634_set_state_tooltip);
        this.setHelpUrl("");
    }
};

Blockly.Blocks['PCA9634_AllLED_Brightness'] = {
    init: function () {
        this.appendValueInput("Brightness")
            .setCheck('Number')
            .appendField(Blockly.Msg.kb_chain_pca9634_Allset_brightness_1)
            .appendField(new Blockly.FieldDropdown([["0x01", "1"], ["0x04", "4"],["0x05", "5"],["0x70", "112"]]), "addr")
            .appendField(Blockly.Msg.kb_chain_pca9634_Allset_brightness_3);
        this.setPreviousStatement(true, null);
        this.setNextStatement(true, null);
        this.setColour(230);
        this.setTooltip(Blockly.Msg.kb_chain_pca9634_Allset_brightness_tooltip);
        this.setHelpUrl("");
    },
    xmlToolbox: function() {
		return $(document.createElement('block')).attr({
			type: 'PCA9634_AllLED_Brightness'
		}).append('\
		   <value name="Brightness">\
			   <shadow type="PCA9634_AllLED_Brightness.Brightness">\
			   </shadow>\
		   </value>'
	   );
    }
};

Blockly.Blocks["PCA9634_AllLED_Brightness.Brightness"] = {
	init: function() {
		this.appendDummyInput()
			.appendField(new Blockly.FieldNumber(255, 0, 255), 'VALUE');
		this.setOutput(true, 'Number');
		this.setPreviousStatement(false);
		this.setNextStatement(false);
		this.setColour(math_colour);
	this.setTooltip("");
	this.setHelpUrl("");
	},
	// custom xmlToolboxcolumn
	xmlToolbox: function() {
		return null; // hidden block
	}
};

Blockly.Blocks['PCA9634_AllLED_State'] = {
    init: function () {
        this.appendDummyInput()
            .appendField(Blockly.Msg.kb_chain_pca9634_Allset_state_1)
            .appendField(new Blockly.FieldDropdown([["0x01", "1"], ["0x04", "4"],["0x05", "5"],["0x70", "112"]]), "addr")
            .appendField(Blockly.Msg.kb_chain_pca9634_Allset_state_3)
            .appendField(new Blockly.FieldDropdown([["ON", "1"], ["OFF", "0"]]), "state");
        this.setPreviousStatement(true, null);
        this.setNextStatement(true, null);
        this.setColour(230);
        this.setTooltip(Blockly.Msg.kb_chain_pca9634_Allset_state_tooltip);
        this.setHelpUrl("");
    }
};

Blockly.Blocks['PCA9634_PWM_Servo'] = {
    init: function () {
        this.appendValueInput("PWM")
            .setCheck('Number')
            .appendField(Blockly.Msg.kb_chain_pca9634_PWM_Servo_1)
            .appendField(new Blockly.FieldDropdown([["0x01", "1"], ["0x04", "4"],["0x05", "5"],["0x70", "112"]]), "addr")
            .appendField(Blockly.Msg.kb_chain_pca9634_PWM_Servo_2)
            .appendField(new Blockly.FieldDropdown([["1", "7"], ["2", "6"], ["3", "5"], ["4", "4"], ["5", "3"], ["6", "2"], ["7", "1"], ["8", "0"]]), "pin")
            .appendField(Blockly.Msg.kb_chain_pca9634_PWM_Servo_3);
        this.setPreviousStatement(true, null);
        this.setNextStatement(true, null);
        this.setColour(230);
        this.setTooltip(Blockly.Msg.kb_chain_pca9634_PWM_Servo_tooltip);
        this.setHelpUrl("");
    },
    xmlToolbox: function() {
		return $(document.createElement('block')).attr({
			type: 'PCA9634_PWM_Servo'
		}).append('\
		   <value name="PWM">\
			   <shadow type="PCA9634_PWM_Servo.PWM">\
			   </shadow>\
		   </value>'
	   );
    }
};

Blockly.Blocks["PCA9634_PWM_Servo.PWM"] = {
	init: function() {
		this.appendDummyInput()
			.appendField(new Blockly.FieldNumber(90, 0, 180), 'VALUE');
		this.setOutput(true, 'Number');
		this.setPreviousStatement(false);
		this.setNextStatement(false);
		this.setColour(math_colour);
	this.setTooltip("");
	this.setHelpUrl("");
	},
	// custom xmlToolboxcolumn
	xmlToolbox: function() {
		return null; // hidden block
	}
};