Blockly.Blocks['Degree_compass'] = {
    init: function(){
        this.jsonInit({
            "type": "Degree_compass",
            "message0": Blockly.Msg.KB_chain_Degree_compass,
            "output": null,
            "colour": 10,
            "tooltip": "",
            "helpUrl": ""
          });
    }
};