Blockly.Msg.BME680_GET_TEMPERATURE_MESSAGE = "อ่านค่าอุณหภูมิ (หน่วยองศาเซลเซียส)";
Blockly.Msg.BME680_GET_TEMPERATURE_TOOLTIP = "อ่านค่าอุณหภูมิจากโมดูล KB Chain VOC Sensor";

Blockly.Msg.BME680_GET_HUMIDUTY_MESSAGE = "อ่านค่าความชื้น (หน่วย %%RH)";
Blockly.Msg.BME680_GET_HUMIDUTY_TOOLTIP = "อ่านค่าความชื้นจาก KB Chain VOC Sensor";

Blockly.Msg.BME680_GET_PRESSURE_MESSAGE = "อ่านค่าความกดอากาศ (หน่วย hPa)";
Blockly.Msg.BME680_GET_PRESSURE_TOOLTIP = "อ่านค่าความกดอากาศจาก KB Chain VOC Sensor";

Blockly.Msg.BME680_GET_GAS_RESISTANCE_MESSAGE = "อ่านค่าความต้านทานแก๊ส (หน่วยโอห์ม)";
Blockly.Msg.BME680_GET_GAS_RESISTANCE_TOOLTIP = "อ่านค่าความต้านทานแก๊สจาก KB Chain VOC Sensor";

Blockly.Msg.BME680_GET_ALTITUDE_MESSAGE = "อ่านค่าความสูงจากระดับน้ำทะเล (หน่วยเมตร)";
Blockly.Msg.BME680_GET_ALTITUDE_TOOLTIP = "อ่านค่าความสูงจากระดับน้ำทะเลจาก KB Chain VOC Sensor";
