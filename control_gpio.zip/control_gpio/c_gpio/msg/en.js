Blockly.Msg.set_gpio_TEXT_TITLE   = "Set GPIO";
Blockly.Msg.set_gpio_TEXT_1   = "PIN";
Blockly.Msg.set_gpio_TEXT_2   = "State";
Blockly.Msg.set_gpio_TEXT_TOOLTIP = "Set GPIO Status";
Blockly.Msg.set_gpio_TEXT_HELPURL = "";

Blockly.Msg.get_gpio_TEXT_TITLE   = "Read GPIO";
Blockly.Msg.get_gpio_TEXT_1   = "PIN";
Blockly.Msg.get_gpio_TEXT_TOOLTIP = "Read GPIO Status";
Blockly.Msg.get_gpio_TEXT_HELPURL = "";
