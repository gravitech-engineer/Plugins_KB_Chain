Blockly.Msg.ADS1015_READ_ANALOG_MESSAGE = "อ่านค่าแอนะล็อกที่ขา %1";
Blockly.Msg.ADS1015_READ_ANALOG_TOOLTIP = "อ่านค่าแอนะล็อกความละเอียด 12 บิต ( 0-2047) จาก KB Chain 4-CH 12-BIT ADC";

Blockly.Msg.ADS1015_SET_GAIN_MESSAGE = "กำหนดแรงดันเต็มสเกลเป็น %1";
Blockly.Msg.ADS1015_SET_GAIN_TOOLTIP = "กำหนดค่าแรงดันสูงสุดที่ KB Chain 4-CH 12-BIT ADC สามารถวัดได้";

Blockly.Msg.ADS1015_READ_VOLTAGE_MESSAGE = "อ่านค่าแรงดันไฟฟ้าที่ขา %1";
Blockly.Msg.ADS1015_READ_VOLTAGE_TOOLTIP = "อ่านค่าแรงดันไฟฟ้าจาก KB Chain 4-CH 12-BIT ADC";
