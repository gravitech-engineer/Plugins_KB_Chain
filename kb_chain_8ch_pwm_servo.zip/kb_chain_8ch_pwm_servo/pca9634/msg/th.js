Blockly.Msg.kb_chain_pca9634_set_brightness_1 = "LED Address";
Blockly.Msg.kb_chain_pca9634_set_brightness_2 = "ช่อง";
Blockly.Msg.kb_chain_pca9634_set_brightness_3 = "ความสว่าง";
Blockly.Msg.kb_chain_pca9634_set_brightness_tooltip = "Address: 0x01 - 0x07 & 0x70 | ความสว่าง: 0 - 255";

Blockly.Msg.kb_chain_pca9634_Allset_brightness_1 = "LED Address";
Blockly.Msg.kb_chain_pca9634_Allset_brightness_3 = "(ช่อง:1 - 8) ความสว่าง";
Blockly.Msg.kb_chain_pca9634_Allset_brightness_tooltip = "Address: 0x01 - 0x07 & 0x70 | Brightness: 0 - 255";

Blockly.Msg.kb_chain_pca9634_set_state_1 = "LED Address";
Blockly.Msg.kb_chain_pca9634_set_state_2 = "ช่อง";
Blockly.Msg.kb_chain_pca9634_set_state_3 = "สถานะ";
Blockly.Msg.kb_chain_pca9634_set_state_tooltip = "Address: 0x01 - 0x07 & 0x70 | สถานะ: เปิด/ปิด";

Blockly.Msg.kb_chain_pca9634_Allset_state_1 = "LED Address";
Blockly.Msg.kb_chain_pca9634_Allset_state_3 = "(ช่อง:1 - 8) สถานะ";
Blockly.Msg.kb_chain_pca9634_Allset_state_tooltip = "Address: 0x01 - 0x07 & 0x70 | State: ON/OFF";

Blockly.Msg.kb_chain_pca9634_PWM_Servo_1 = "Servo Address";
Blockly.Msg.kb_chain_pca9634_PWM_Servo_2 = "ช่อง";
Blockly.Msg.kb_chain_pca9634_PWM_Servo_3 = "มุม";
Blockly.Msg.kb_chain_pca9634_PWM_Servo_tooltip = "Address: 0x01 - 0x07 & 0x70 | มุม: 0 - 180";