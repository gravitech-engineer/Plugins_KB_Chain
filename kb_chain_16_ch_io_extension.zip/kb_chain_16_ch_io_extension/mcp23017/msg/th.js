Blockly.Msg.MCP23017_DIGITAL_WRITE_MESSAGE = "เขียนค่าดิจิทัลที่ช่อง %1 เป็น %2";
Blockly.Msg.MCP23017_DIGITAL_WRITE_TOOLTIP = "ใช้เขียนค่าดิจิทัลขา PA0 - PA7 และ PB0 - PB7 บน KB Chain 16-CH IO Extension";

Blockly.Msg.MCP23017_DIGITAL_READ_MESSAGE = "อ่านค่าดิจิทัลที่ช่อง %1";
Blockly.Msg.MCP23017_DIGITAL_READ_TOOLTIP = "ใช้อ่านค่าดิจิทัลขา PA0 - PA7 และ PB0 - PB7 บน KB Chain 16-CH IO Extension";
