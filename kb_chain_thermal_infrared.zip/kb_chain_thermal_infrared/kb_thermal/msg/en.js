Blockly.Msg.kb_thermal_TEXT_TITLE   = "Read Temperature";
Blockly.Msg.kb_thermal_TEXT_TOOLTIP = "Read Temperature";
Blockly.Msg.kb_thermal_TEXT_HELPURL = "www.gravitechthai.com";


