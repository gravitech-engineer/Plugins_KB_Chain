const Ultra_BEGIN = "DEV_I2C1.KBUltrasonic()";

Blockly.JavaScript['KBUltrasonic_Readdistance3'] = function (block) {
	var code = Ultra_BEGIN + `.Readdistanc()\n`;
	//console.log(code);
	return [code, Blockly.JavaScript.ORDER_ATOMIC];
  };