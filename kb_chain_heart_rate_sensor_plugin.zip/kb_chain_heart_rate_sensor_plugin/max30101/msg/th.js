Blockly.Msg.MAX30101_HEART_RATE = "อ่านค่าอัตราการเต้นของหัวใจ (bpm)";
Blockly.Msg.MAX30101_RAW_DATA = "เซ็นเซอร์วัดอัตราการเต้นของหัวใจ อ่านข้อมูลดิบ";
Blockly.Msg.MAX30101_RED = "แสงสีแดง";
Blockly.Msg.MAX30101_IR = "แสงอินฟาเรด";
