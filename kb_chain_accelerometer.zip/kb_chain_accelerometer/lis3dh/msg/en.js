Blockly.Msg.LIS3DH_ACCELERATION = "acceleration (mg)";
Blockly.Msg.LIS3DH_ACCELEROMETER_ADDRESS = "Accelerometer address";
Blockly.Msg.LIS3DH_READ_ACCELERATION = "read acceleration (mg)";
Blockly.Msg.LIS3DH_READ_ADC = "read ADC";

