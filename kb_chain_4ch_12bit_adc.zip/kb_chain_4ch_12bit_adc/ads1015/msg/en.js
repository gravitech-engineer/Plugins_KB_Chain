Blockly.Msg.ADS1015_READ_ANALOG_MESSAGE = "Read analog pin %1";
Blockly.Msg.ADS1015_READ_ANALOG_TOOLTIP = "Read analog 12 bit from KB Chain 4-CH 12-BIT ADC";

Blockly.Msg.ADS1015_SET_GAIN_MESSAGE = "Set full-scale to %1";
Blockly.Msg.ADS1015_SET_GAIN_TOOLTIP = "Set maximum input voltage";

Blockly.Msg.ADS1015_READ_VOLTAGE_MESSAGE = "Read voltage pin %1";
Blockly.Msg.ADS1015_READ_VOLTAGE_TOOLTIP = "Read voltage from KB Chain 4-CH 12-BIT ADC";
