Blockly.Msg.KB_chain_Degree_compass = "Compass 0 - 360 Degree";
