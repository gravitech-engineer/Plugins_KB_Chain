
Blockly.Msg.BH1745NUC_GET_COLOR_MESSAGE = "RGB Light Sensor    get raw color %1";
Blockly.Msg.BH1745NUC_GET_COLOR_OPTION_RED = "Red";
Blockly.Msg.BH1745NUC_GET_COLOR_OPTION_GREEN = "Green";
Blockly.Msg.BH1745NUC_GET_COLOR_OPTION_BLUE = "Blue";
Blockly.Msg.BH1745NUC_GET_COLOR_TOOLTIP = "Read RGB value from KB Chain RGB Light Sensor";
