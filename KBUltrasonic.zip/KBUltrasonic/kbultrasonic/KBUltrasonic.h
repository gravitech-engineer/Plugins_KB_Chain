#ifndef __KBUltrasonic_H__
#define __KBUltrasonic_H__

#include "driver.h"
#include "device.h"
#include "i2c-dev.h"


class KBUltrasonic : public Device
{
private:
	enum
	{
		s_detect,
		s_read,
		s_error,
		s_wait
	} state;
	TickType_t tickcnt, polling_tickcnt;
	I2CDev *i2c;

    uint8_t reg = 0x06;
	int GG = 0;
	bool dataUpdateFlag = false;	

public:
	// constructor
	KBUltrasonic();
	
	// override
	void init(void);
	void process(Driver *drv);
	int prop_count(void);
	bool prop_name(int index, char *name);
	bool prop_unit(int index, char *unit);
	bool prop_attr(int index, char *attr);
	bool prop_read(int index, char *value);
	bool prop_write(int index, char *value);

	// method
	int Readdistanc(void);
};

#endif