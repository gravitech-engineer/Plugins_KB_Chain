Blockly.Msg.DRV8830_SPEED_TITLE = "KB Motor Speed";
Blockly.Msg.DRV8830_SPEED_TOOLTIP = "Set KB Motor speed 0 to 100% (negative speed for reverse direction)";
Blockly.Msg.DRV8830_SPEED_HELPURL = "";

Blockly.Msg.MOTOR = "Motor";
Blockly.Msg.MOTOR_SPEED = "Speed";
Blockly.Msg.MOTOR_STATE = "State";
Blockly.Msg.MOTOR_STANDBY = "StandBy";
Blockly.Msg.MOTOR_REVERSE = "Reverse";
Blockly.Msg.MOTOR_FORWARD = "Forward";
Blockly.Msg.MOTOR_BRAKE = "Brake";
