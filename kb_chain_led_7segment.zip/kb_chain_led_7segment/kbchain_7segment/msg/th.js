Blockly.Msg.KB_CHAIN_FORCE_SENSOR_GET_RAW_MESSAGE = "เซ็นเซอร์วัดแรงกด อ่านค่า %1";
Blockly.Msg.KB_CHAIN_FORCE_SENSOR_GET_RAW_TOOLTIP = "";
