#include <stdio.h>
#include <math.h>
#include "esp_system.h"
#include "kidbright32.h"
#include "driver/uart.h"
#include "soc/uart_struct.h"
#include "IRreceiver.h"

IRreceiver::IRreceiver() {
	channel = 0x00;
	address = 0x7A;
}

void IRreceiver::init(void)
{
	state = s_detect;
	initialized = true;
	
	i2c_config_t conf;

	conf.mode = I2C_MODE_MASTER;
	conf.sda_io_num = CHAIN_SDA_GPIO;
	conf.sda_pullup_en = GPIO_PULLUP_ENABLE;
	conf.scl_io_num = CHAIN_SCL_GPIO;
	conf.scl_pullup_en = GPIO_PULLUP_ENABLE;
	conf.master.clk_speed = 100E3; // Set speed to 100kHz

	i2c_param_config(I2C_NUM_1, &conf);
}

int IRreceiver::prop_count(void)
{
	// not supported
	return 0;
}

bool IRreceiver::prop_name(int index, char *name)
{
	// not supported
	return false;
}

bool IRreceiver::prop_unit(int index, char *unit)
{
	// not supported
	return false;
}

bool IRreceiver::prop_attr(int index, char *attr)
{
	// not supported
	return false;
}

bool IRreceiver::prop_read(int index, char *value)
{
	// not supported
	return false;
}

bool IRreceiver::prop_write(int index, char *value)
{
	// not supported
	return false;
}

void IRreceiver::process(Driver *drv)
{
	i2c = (I2CDev *)drv;
	uint8_t data2[5];
	
	switch (state)
	{
	case s_detect:
		// detect i2c device
		if (i2c->detect(channel, address) == ESP_OK)
		{
			error = false;
			initialized = true;
			dataUpdateFlag = true;
			state = s_read;
			
		}
		else
		{
			state = s_error;
			
		}
		break;

	case s_read:
		if (dataUpdateFlag)
		{
			tickcnt = get_tickcnt();
			i2c->write(channel, address, &reg, 1);
			
			if (i2c->read(channel, address, NULL, 0, data2, 4) == ESP_OK)
			{
				buttonIR = data2[0];
				Data3 = (data2[0] * 255) + data2[1];
				// Data3 = data2[0];
				if (Data3 != 255 && Data3 != 1 && Data3 != 65280){
					press[p] = Data3;
					p++;
					if (p>1){
						p = 0;
					}
				}else {
					previous = true;
					if (press[0] == 255){
						press[p] = press[1] ;
					} else if (press[1] == 255){
						press[p] = press[0] ;
					}else if (press[0] == 255 && press[1] == 255){
						press[p] = 0;
					}
				}
			}
			else
			{
				//buttonIR = 30;
				state = s_error;
			}
		}
		break;

	case s_error:
		//Data3 = 0;
		// set error flag
		error = true;
		// clear initialized flag
		initialized = false;
		// get current tickcnt
		tickcnt = get_tickcnt();
		// goto wait and retry with detect state
		state = s_wait;
		break;

	case s_wait:
		// delay 1000ms before retry detect
		if (is_tickcnt_elapsed(tickcnt, 1000))
		{
			state = s_detect;
		}
		break;
	}
}
int IRreceiver::IRpressed(uint8_t ArrayButton)
{
	reg = 0x10;
	if (ArrayButton == buttonIR){
		return 1;
	}
	return 0;
}


int IRreceiver::IRReader(int SL)
{
	reg = 0x09;
	if (previous && SL == 1){
		previous = false;
		return press[p] ;
	}else if (SL == 2){
		return Data3;
	}
	return Data3;
}

/*
int IRreceiver::IRStatus(void)
{
	reg = 0x10;
	return buttonIR ;
}


char *IRreceiver::IRStatus(void)
{
	switch (buttonIR){
    	case 1:
      		return "ON/OFF"; break;
    	case 2:
    	  	return "Mode"; break;
    	case 3:
    	  	return "Mute"; break;
    	case 4:
      		return "Play/Pause"; break;
    	case 5:
      		return "Backward"; break;
    	case 6:
      		return "Forward"; break;
    	case 7:
      		return "EQ"; break;
    	case 8:
      		return "Minus"; break;
    	case 9:
      		return "Plus"; break;
    	case 10:
      		return "0"; break;
    	case 11:
      		return "Reverse"; break;
    	case 12:
      		return "SDScan"; break;
    	case 13:
      		return "1"; break;
    	case 14:
      		return "2"; break;
    	case 15:
      		return "3"; break;
    	case 16:
      		return "4"; break;
    	case 17:
      		return "5"; break;
    	case 18:
      		return "6"; break;
    	case 19:
      		return "7"; break;
    	case 20:
      		return "8"; break;
    	case 21:
    	  	return "9"; break;
  }
    return "Wait";
}*/