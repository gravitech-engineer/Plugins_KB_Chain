
Blockly.Msg.MIC_GET_DATA_MESSAGE = "เซ็นเซอร์เสียง    อ่านข้อมูลดิบ";
Blockly.Msg.MIC_GET_DATA_TOOLTIP = "อ่านข้อมูลดิบจาก KB Chain Sound Detector";
