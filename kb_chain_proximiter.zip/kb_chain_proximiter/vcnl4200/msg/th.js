Blockly.Msg.PROXIMITY_READ_MESSAGE = "อ่านค่า proximity";
Blockly.Msg.PROXIMITY_READ_TOOLTIP = "";

Blockly.Msg.PROXIMITY_READ_AMBIEANT_MESSAGE = "อ่านค่า ambient";
Blockly.Msg.PROXIMITY_READ_AMBIEANT_TOOLTIP = "";
