
Blockly.JavaScript['Degree_compass'] = function(block) {
	// TODO: Assemble JavaScript into code variable.
	var code = 'DEV_I2C1.compass(0, 0x30).getdegree()';
	// TODO: Change ORDER_NONE to the correct strength.
	return [code, Blockly.JavaScript.ORDER_ATOMIC];
  };