
Blockly.Msg.BH1745NUC_GET_COLOR_MESSAGE = "เซ็นเซอร์สี    อ่านข้อมูลดิบสี %1";
Blockly.Msg.BH1745NUC_GET_COLOR_OPTION_RED = "แดง";
Blockly.Msg.BH1745NUC_GET_COLOR_OPTION_GREEN = "เขียว";
Blockly.Msg.BH1745NUC_GET_COLOR_OPTION_BLUE = "น้ำเงิน";
Blockly.Msg.BH1745NUC_GET_COLOR_TOOLTIP = "อ่านค่าสีที่ได้จากเซ็นเซอร์ KB Chain RGB Light Sensor";
