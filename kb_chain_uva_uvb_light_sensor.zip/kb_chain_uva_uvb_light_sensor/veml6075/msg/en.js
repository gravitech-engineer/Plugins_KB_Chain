Blockly.Msg.VEML6075_READ_UVI = "Read UV Index";
Blockly.Msg.VEML6075_READ_UVA = "Read UVA";
Blockly.Msg.VEML6075_READ_UVB = "Read UVB";
