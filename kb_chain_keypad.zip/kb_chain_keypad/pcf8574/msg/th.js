Blockly.Msg.KB_CHAIN_KEYPAD_ON_PESS_MESSAGE = "Keypad เมื่อกดปุ่ม ให้ %1 %2";
Blockly.Msg.KB_CHAIN_KEYPAD_ON_PESS_TOOLTIP = "";

Blockly.Msg.KB_CHAIN_KEYPAD_ON_RELE_MESSAGE = "Keypad เมื่อปล่อยปุ่ม ให้ %1 %2";
Blockly.Msg.KB_CHAIN_KEYPAD_ON_RELE_TOOLTIP = "";

Blockly.Msg.KB_CHAIN_KEYPAD_GET_KEY_MESSAGE = "Keypad อ่านปุ่มที่กด (ตัวอักษรรหัสแอสกี)";
Blockly.Msg.KB_CHAIN_KEYPAD_GET_KEY_TOOLTIP = "";

Blockly.Msg.KB_CHAIN_KEYPAD_GET_KEY_STRING_MESSAGE = "Keypad อ่านปุ่มที่กด (ข้อความ)";
Blockly.Msg.KB_CHAIN_KEYPAD_GET_KEY_STRING_TOOLTIP = "";
