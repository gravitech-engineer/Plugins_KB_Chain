Blockly.Blocks['pressedIR'] = {
	init: function() {
		this.jsonInit({
			"message0": Blockly.Msg.IR_PRESSED_VALUE,
			"args0": [{
				"type": "field_dropdown",
				"name": "ArrayButton",
				"options": [
					[ "ON/OFF", "1" ],
					[ "Mode", "2" ],
                    [ "Mute", "3" ],
                    [ "Play/Pause", "4" ],
                    [ "Backward", "5" ],
                    [ "Forward", "6" ],
                    [ "EQ", "7" ],
                    [ "Minus", "8" ],
                    [ "Plus", "9" ],
                    [ "0", "10" ],
                    [ "Repeat", "11" ],
                    [ "SD Scan", "12" ],
                    [ "1", "13" ],
                    [ "2", "14" ],
                    [ "3", "15" ],
                    [ "4", "16" ],
                    [ "5", "17" ],
                    [ "6", "18" ],
                    [ "7", "19" ],
                    [ "8", "20" ],
                    [ "9", "21" ]
				]
			}],
			"output": null,
			"colour": 210,
			"tooltip": "",
			"helpUrl": ""
		});
	}
};
/*
Blockly.Blocks["StatusIR"] = {
    init: function() {
        this.appendDummyInput()
            .appendField(Blockly.Msg.IR_PRESSED_STATUS);
        this.setOutput(true, null);
        this.setColour(160);
    this.setTooltip("");
    this.setHelpUrl("");
    }
};

Blockly.Blocks["ReadIR"] = {
    init: function() {
        this.appendDummyInput()
            .appendField(Blockly.Msg.IR_PRESSED_READER);
        this.setOutput(true, null);
        this.setColour(3);
    this.setTooltip("");
    this.setHelpUrl("");
    }
};*/

Blockly.Blocks['ReadIR'] = {
	init: function() {
		this.jsonInit({
			"message0": Blockly.Msg.IR_PRESSED_READER,
			"args0": [{
				"type": "field_dropdown",
				"name": "SL",
				"options": [
					[ "Show", "1" ],
					[ "Logic", "2" ]
				]
			}],
			"output": null,
			"colour": 210,
			"tooltip": "",
			"helpUrl": ""
		});
	}
};