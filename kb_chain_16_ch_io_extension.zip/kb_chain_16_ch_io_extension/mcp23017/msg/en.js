Blockly.Msg.MCP23017_DIGITAL_WRITE_MESSAGE = "digital write pin %1 to %2";
Blockly.Msg.MCP23017_DIGITAL_WRITE_TOOLTIP = "Write value to pin PA0 - PA7 and PB0 - PB7 on KB Chain 16-CH IO Extension";

Blockly.Msg.MCP23017_DIGITAL_READ_MESSAGE = "digital read pin %1";
Blockly.Msg.MCP23017_DIGITAL_READ_TOOLTIP = "Read value for pin PA0 - PA7 and PB0 - PB7 on KB Chain 16-CH IO Extension";
