Blockly.Msg.kb_chain_TEXT_TITLE   = "Set Relay";
Blockly.Msg.kb_chain_TEXT_CHANNEL   = "Channel";
Blockly.Msg.kb_chain_TEXT_STATE   = "State";
Blockly.Msg.kb_chain_TEXT_TOOLTIP = "Set Relay Status";
Blockly.Msg.kb_chain_TEXT_HELPURL = "";
