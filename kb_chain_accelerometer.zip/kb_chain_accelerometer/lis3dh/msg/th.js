Blockly.Msg.LIS3DH_ACCELERATION = "อ่านค่าความเอียง (mg) ที่แกน";
Blockly.Msg.LIS3DH_ACCELEROMETER_ADDRESS = "เซ็นเซอร์วัดความเอียงหมายเลข";
Blockly.Msg.LIS3DH_READ_ACCELERATION = "อ่านค่าความเอียง (mg) ที่แกน";
Blockly.Msg.LIS3DH_READ_ADC = "อ่านค่าอนาล็อกจาก ADC";

