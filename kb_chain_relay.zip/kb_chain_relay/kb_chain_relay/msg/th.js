Blockly.Msg.kb_chain_TEXT_TITLE   = "กำหนดรีเลย์";
Blockly.Msg.kb_chain_TEXT_CHANNEL   = "ช่อง";
Blockly.Msg.kb_chain_TEXT_STATE   = "สถานะ";
Blockly.Msg.kb_chain_TEXT_TOOLTIP = "กำหนดสถานะรีเลย์";
Blockly.Msg.kb_chain_TEXT_HELPURL = "";