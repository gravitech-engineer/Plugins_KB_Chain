
Blockly.Msg.MIC_GET_DATA_MESSAGE = "Sound Detector    Read raw data";
Blockly.Msg.MIC_GET_DATA_TOOLTIP = "Read raw data from KB Chain Sound Detector";
