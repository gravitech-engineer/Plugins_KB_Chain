const IRremote_BEGIN = "DEV_I2C1.IRreceiver()";

Blockly.JavaScript['pressedIR'] = function (block) {
    var dropdown_ArrayButton = block.getFieldValue('ArrayButton')
	var code = IRremote_BEGIN + `.IRpressed(` + dropdown_ArrayButton + `)\n`;
	return [code, Blockly.JavaScript.ORDER_ATOMIC];
  };
/*
Blockly.JavaScript['StatusIR'] = function (block) {
	var code = IRremote_BEGIN + `.IRStatus()\n`;
	return [code, Blockly.JavaScript.ORDER_ATOMIC];
  };
*/
Blockly.JavaScript['ReadIR'] = function (block) {
  var dropdown_SL = block.getFieldValue('SL')
  var code = IRremote_BEGIN + `.IRReader(` + dropdown_SL + `)\n`;
  return [code, Blockly.JavaScript.ORDER_ATOMIC];
  };
  