Blockly.Msg.IR_PRESSED_VALUE = "Button used = %1";
Blockly.Msg.IR_PRESSED_STATUS = "IR STATUS";
Blockly.Msg.IR_PRESSED_READER = "Read Button Value %1";