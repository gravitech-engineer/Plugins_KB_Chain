#ifndef __pca9634_H__
#define __pca9634_H__

#include "driver.h"
#include "device.h"
#include "i2c-dev.h"
#include "kidbright32.h"

#define oePin 15

#define LED_Mode_1 0x00
#define LED_Mode_2 0x01

#define Mode1_AllCall 0x01
#define Mode2_OUTDRV 0x04
#define Mode2_INVRT 0x10
#define Mode2_OI 0x14

#define LED_OFF_ALL 0x00
#define LED_ON_ALL 0x55
#define LED_PWM_ALL 0xAA
#define LEDOUT0 0x0C
#define LEDOUT1 0x0D

class pca9634 : public Device {
	private:		
		enum {
			s_detect,
			s_read,
			s_wait,
			s_error
		} state;
		TickType_t tickcnt, polling_tickcnt;
		
		I2CDev *i2c ;
        uint8_t reg[2];
		uint8_t pinset;
		uint8_t setMode[2] = {LED_Mode_1, Mode1_AllCall};
		uint8_t setMode2[2] = {LED_Mode_2, Mode2_OI};
		uint8_t setPWMALL[2] = {LEDOUT0, LED_PWM_ALL};
		uint8_t setPWMALL2[2] = {LEDOUT1, LED_PWM_ALL};
		uint8_t setModeAllON[2] = {LEDOUT0, LED_ON_ALL};
		uint8_t setModeAllON2[2] = {LEDOUT1, LED_ON_ALL};
		uint8_t ModeAllOff[2] = {LEDOUT0, LED_OFF_ALL};
		uint8_t ModeAllOff2[2] = {LEDOUT1, LED_OFF_ALL};
		uint8_t setGRPFreq[2] = {0x0B, 0x1A};



	public:
		// constructor
		pca9634(int bus_ch, int dev_addr) ;
		
		// override
		void init(void);
		void process(Driver *drv);
		int prop_count(void);
		bool prop_name(int index, char *name);
		bool prop_unit(int index, char *unit);
		bool prop_attr(int index, char *attr);
		bool prop_read(int index, char *value);
		bool prop_write(int index, char *value);
		
		// method
		void chanPwm(uint8_t pin, uint8_t value);
		void allchanPwm(uint8_t value);
		void Onstate(uint8_t pin, uint8_t state);
		void allstate(uint8_t state);
		void setServoPWM ( uint8_t outPin, uint8_t servoDegree);
		uint8_t bitSet(int v, int setbit);
		void pinType(uint8_t pinMode);
		
		
};

#endif