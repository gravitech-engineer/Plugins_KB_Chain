Blockly.Msg.VEML6075_READ_UVI = "อ่านค่าดัชนีรังสีอัลตราไวโอเลต (UV Index)";
Blockly.Msg.VEML6075_READ_UVA = "อ่านค่าอัลตราไวโอเลต เอ (UVA)";
Blockly.Msg.VEML6075_READ_UVB = "อ่านค่าอัลตราไวโอเลต บี (UVB)";
