Blockly.Msg.write_led_TEXT_TITLE   = "Set LED";
Blockly.Msg.write_led_TEXT_1   = "PIN";
Blockly.Msg.write_led_TEXT_2   = "State";
Blockly.Msg.write_led_TEXT_TOOLTIP = "Set LED Status";
Blockly.Msg.write_led_TEXT_HELPURL = "";
