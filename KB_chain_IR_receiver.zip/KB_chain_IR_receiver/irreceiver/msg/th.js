Blockly.Msg.IR_PRESSED_VALUE = "ใช้งานปุ่มกด = %1";
Blockly.Msg.IR_PRESSED_STATUS = "สถานะอินฟราเรท";
Blockly.Msg.IR_PRESSED_READER = "อ่านค่าปุ่มกด %1";