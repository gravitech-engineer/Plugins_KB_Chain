Blockly.Msg.kb_thermal_TEXT_TITLE   = "อ่านค่าอุณหภูมิ";
Blockly.Msg.kb_thermal_TEXT_TOOLTIP = "อ่านค่าอุณหภูมิ";
Blockly.Msg.kb_thermal_TEXT_HELPURL = "www.gravitechthai.com";
