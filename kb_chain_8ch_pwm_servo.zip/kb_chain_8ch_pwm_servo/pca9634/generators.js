Blockly.JavaScript['PCA9634_LED_Brightness'] = function (block) {
    var dropdown_addr = block.getFieldValue('addr');
    var dropdown_pin = block.getFieldValue('pin');
    var number_brightness = Blockly.JavaScript.valueToCode(block, 'Brightness', Blockly.JavaScript.ORDER_ATOMIC);
    // TODO: Assemble JavaScript into code variable.
    var code = 'DEV_I2C1.pca9634(0,' + dropdown_addr + ').chanPwm(' + dropdown_pin + ',' + number_brightness + ');\n';
    return code;
};

Blockly.JavaScript["PCA9634_LED_Brightness.Brightness"] = function (block) {
    // Numeric value.
    var code = parseInt(block.getFieldValue('VALUE'));
    var order = code >= 1 ? Blockly.JavaScript.ORDER_ATOMIC : Blockly.JavaScript.ORDER_UNARY_NEGATION;
    return [code, order];
};

Blockly.JavaScript['PCA9634_LED_State'] = function (block) {
    var dropdown_addr = block.getFieldValue('addr');
    var dropdown_pin = block.getFieldValue('pin');
    var dropdown_state = block.getFieldValue('state');
    // TODO: Assemble JavaScript into code variable.
    var code = 'DEV_I2C1.pca9634(0,' + dropdown_addr + ').Onstate(' + dropdown_pin + ',' + dropdown_state + ');\n';
    return code;
};

Blockly.JavaScript['PCA9634_AllLED_Brightness'] = function (block) {
    var dropdown_addr = block.getFieldValue('addr');
    var number_brightness = Blockly.JavaScript.valueToCode(block, 'Brightness', Blockly.JavaScript.ORDER_ATOMIC);
    // TODO: Assemble JavaScript into code variable.
    var code = 'DEV_I2C1.pca9634(0,' + dropdown_addr + ').allchanPwm(' + number_brightness + ');\n';
    return code;
};

Blockly.JavaScript["PCA9634_AllLED_Brightness.Brightness"] = function (block) {
    // Numeric value.
    var code = parseInt(block.getFieldValue('VALUE'));
    var order = code >= 1 ? Blockly.JavaScript.ORDER_ATOMIC : Blockly.JavaScript.ORDER_UNARY_NEGATION;
    return [code, order];
};

Blockly.JavaScript['PCA9634_AllLED_State'] = function (block) {
    var dropdown_addr = block.getFieldValue('addr');
    var dropdown_state = block.getFieldValue('state');
    // TODO: Assemble JavaScript into code variable.
    var code = 'DEV_I2C1.pca9634(0,' + dropdown_addr + ').allstate(' + dropdown_state + ');\n';
    return code;
};

Blockly.JavaScript['PCA9634_PWM_Servo'] = function (block) {
    var dropdown_addr = block.getFieldValue('addr');
    var dropdown_pin = block.getFieldValue('pin');
    var number_PWM = Blockly.JavaScript.valueToCode(block, 'PWM', Blockly.JavaScript.ORDER_ATOMIC);
    // TODO: Assemble JavaScript into code variable.
    var code = 'DEV_I2C1.pca9634(0,' + dropdown_addr + ').setServoPWM(' + dropdown_pin + ',' + number_PWM + ');\n';
    return code;
};

Blockly.JavaScript["PCA9634_PWM_Servo.PWM"] = function (block) {
    // Numeric value.
    var code = parseInt(block.getFieldValue('VALUE'));
    var order = code >= 1 ? Blockly.JavaScript.ORDER_ATOMIC : Blockly.JavaScript.ORDER_UNARY_NEGATION;
    return [code, order];
};