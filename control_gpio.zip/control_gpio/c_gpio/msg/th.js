Blockly.Msg.set_gpio_TEXT_TITLE   = "กำหนดไอโอ";
Blockly.Msg.set_gpio_TEXT_1   = "ขา";
Blockly.Msg.set_gpio_TEXT_2   = "สถานะ";
Blockly.Msg.set_gpio_TEXT_TOOLTIP = "กำหนดสถานะไอโอ";
Blockly.Msg.set_gpio_TEXT_HELPURL = "";

Blockly.Msg.get_gpio_TEXT_TITLE   = "อ่านไอโอ";
Blockly.Msg.get_gpio_TEXT_1   = "ขา";
Blockly.Msg.get_gpio_TEXT_TOOLTIP = "อ่านสถานะจากไอโอ";
Blockly.Msg.get_gpio_TEXT_HELPURL = "";
