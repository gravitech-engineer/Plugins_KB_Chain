#include <stdio.h>
#include <string.h>
#include <math.h>
#include "esp_system.h"
#include "kidbright32.h"
#include "driver/uart.h"
#include "soc/uart_struct.h"
#include "KBUltrasonic.h"

KBUltrasonic::KBUltrasonic() {
	channel = 0x00;
	address = 0x7D;
}

void KBUltrasonic::init(void)
{
	state = s_detect;
	initialized = true;
	
	i2c_config_t conf;

	conf.mode = I2C_MODE_MASTER;
	conf.sda_io_num = CHAIN_SDA_GPIO;
	conf.sda_pullup_en = GPIO_PULLUP_ENABLE;
	conf.scl_io_num = CHAIN_SCL_GPIO;
	conf.scl_pullup_en = GPIO_PULLUP_ENABLE;
	conf.master.clk_speed = 100E3; // Set speed to 100kHz

	i2c_param_config(I2C_NUM_1, &conf);
}

int KBUltrasonic::prop_count(void)
{
	// not supported
	return 0;
}

bool KBUltrasonic::prop_name(int index, char *name)
{
	// not supported
	return false;
}

bool KBUltrasonic::prop_unit(int index, char *unit)
{
	// not supported
	return false;
}

bool KBUltrasonic::prop_attr(int index, char *attr)
{
	// not supported
	return false;
}

bool KBUltrasonic::prop_read(int index, char *value)
{
	// not supported
	return false;
}

bool KBUltrasonic::prop_write(int index, char *value)
{
	// not supported
	return false;
}

void KBUltrasonic::process(Driver *drv)
{
	i2c = (I2CDev *)drv;
	uint8_t data2[3];
	switch (state)
	{
	case s_detect:
		// detect i2c device
		if (i2c->detect(channel, address) == ESP_OK)
		{
			error = false;
			initialized = true;
			dataUpdateFlag = true;
			state = s_read;
		}
		else
		{
			state = s_error;
		}
		break;

	case s_read:
		if (dataUpdateFlag)
		{
			tickcnt = get_tickcnt();
			i2c->write(channel, address, &reg, 1);
			if (i2c->read(channel, address, NULL, 0, data2, 2) == ESP_OK)
			{
				GG = (data2[0]&0xFF) | data2[1] ;
				// GG = 25;
				
			}
			else
			{
				state = s_error;
			}
		}
		break;

	case s_error:
		// set error flag
		error = true;
		// clear initialized flag
		initialized = false;
		// get current tickcnt
		tickcnt = get_tickcnt();
		// goto wait and retry with detect state
		state = s_wait;
		break;

	case s_wait:
		// delay 1000ms before retry detect
		if (is_tickcnt_elapsed(tickcnt, 1000))
		{
			state = s_detect;
		}
		break;
	}
}

int KBUltrasonic::Readdistanc(void)
{
	if (GG > 400){
		return 0;
	}
	return GG;
}