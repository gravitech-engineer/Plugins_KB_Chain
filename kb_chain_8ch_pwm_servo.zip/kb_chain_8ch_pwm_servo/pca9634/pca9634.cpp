#ifndef __pca9634_CPP__
#define __pca9634_CPP__

#include "pca9634.h"

pca9634::pca9634(int bus_ch, int dev_addr) {
	channel = bus_ch;
	address = dev_addr;
	polling_ms = 100;
}

void pca9634::init(void) {
	// clear error flag
	error = true;
	// set initialized flag
	initialized = false;

	// Reset speed of I2C
	i2c_config_t conf;

	conf.mode = I2C_MODE_MASTER;
	conf.sda_io_num = CHAIN_SDA_GPIO;
	conf.sda_pullup_en = GPIO_PULLUP_ENABLE;
	conf.scl_io_num = CHAIN_SCL_GPIO;
	conf.scl_pullup_en = GPIO_PULLUP_ENABLE;
	conf.master.clk_speed = 1E3;

	i2c_param_config(I2C_NUM_1, &conf);

	// Set new timeout of i2c
	i2c_set_timeout(I2C_NUM_1, 20000);
	
	state = s_detect;
}

int pca9634::prop_count(void) {
	// not supported
	return 0;
}

bool pca9634::prop_name(int index, char *name) {
	// not supported
	return false;
}

bool pca9634::prop_unit(int index, char *unit) {
	// not supported
	return false;
}

bool pca9634::prop_attr(int index, char *attr) {
	// not supported
	return false;
}

bool pca9634::prop_read(int index, char *value) {
	// not supported
	return false;
}

bool pca9634::prop_write(int index, char *value) {
	// not supported
	return false;
}
// --------------------------------------

void pca9634::process(Driver *drv) {
	i2c = (I2CDev *)drv;
	switch (state) {
		case s_detect:
			// detect i2c device
			if (i2c->detect(channel, address) == ESP_OK) {
				state = s_read;
				for (int i = 0 ; i<2 ; i++){  // Set Mode 1: PCA9634 responds to LED All Call I2C-bus address
					i2c->write(channel, address, &setMode[i], 2);
				}
				for (int i = 0 ; i<2 ; i++){ // Set Mode 2: 0b00010100
					i2c->write(channel, address, &setMode2[i], 2);
				}
				vTaskDelay(50 / portTICK_PERIOD_MS);
				// for (int i = 0 ; i<2 ; i++){ // Set LEDOUT0: LDRAll 11
				// 	i2c->write(channel, address, &ModeAllOff[i], 2);
				// }
				
				// for (int i = 0 ; i<2 ; i++){ // Set LEDOUT1: LDRAll 11
				// 	i2c->write(channel, address, &ModeAllOff2[i], 2);
				// }
				

			}
			//  else {
			// 	state = s_error;
			// }
			break;
	
		case s_read: {
			vTaskDelay(50 / portTICK_PERIOD_MS);
		}
		case s_wait:
			if (error) {
				// wait polling_ms timeout
				// if (is_tickcnt_elapsed(tickcnt, polling_ms)) {
					// state = s_detect;
				// }
			}
			break;

		case s_error:			
			// set error flag
			error = true;
			// clear initialized flag
			initialized = false;
			// get current tickcnt
			tickcnt = get_tickcnt();
			// goto wait and retry with detect state
			state = s_wait;
			break;

	}
}

// Method
void pca9634::chanPwm(uint8_t pin, uint8_t value)
{
    reg[0] = pin + 2;
	pinType(8);
	if (value < 0){
		reg[1] = 0;
	}else if (value > 255){
		reg[1] = 255;
	}else {
		reg[1] = value;
	}
	for (int i = 0 ; i<2 ; i++){
		i2c->write(channel, address, &reg[i], 2);
	}
	
}

void pca9634::allchanPwm(uint8_t value)
{
	pinType(8);
	if (value < 0){
		reg[1] = 0;
	}else if (value > 255){
		reg[1] = 255;
	}else {
		reg[1] = value;
	}
	for (int j = 2; j <= 9; j++){
		reg[0] = j;
		for (int i = 0 ; i<2 ; i++){
			i2c->write(channel, address, &reg[i], 2);
		}
	}
}

void pca9634::Onstate(uint8_t pin, uint8_t state)
{
	reg[0] = pin + 2;
	pinType(8);
	if (state == 0){
		reg[1] = 0;
	}else {
		reg[1] = 255;
	}
	for (int i = 0 ; i<2 ; i++){
		i2c->write(channel, address, &reg[i], 2);
	}
}

void pca9634::allstate(uint8_t state)
{
	if (state == 0){
		pinType(10);
		reg[1] = 0;
		for (int j = 2; j <= 9; j++){
		reg[0] = j;
		for (int i = 0 ; i<2 ; i++){
			i2c->write(channel, address, &reg[i], 2);
		}
		}
	}else {
		pinType(9);
		reg[1] = 255;
		for (int j = 2; j <= 9; j++){
		reg[0] = j;
		for (int i = 0 ; i<2 ; i++){
			i2c->write(channel, address, &reg[i], 2);
		}
		}
	}
	
}

void pca9634::setServoPWM (uint8_t outPin, uint8_t servoDegree)
{
	uint8_t duty;
	pinType(outPin);
	
	reg[0] = outPin + 2;
	reg[1] = 0xFF;
	for (int i = 0 ; i<2 ; i++){
		i2c->write(channel, address, &reg[i], 2);
	}
	
	if (servoDegree < 0){
		duty = 26;
	}else if (servoDegree > 180){
		duty = 120;
	}else {
		duty = 26 + ((servoDegree * 0.0107) / 0.0206) ;
	}

  	uint8_t setDuty[2] = {0x0A, duty};
  	for (int i = 0 ; i<2 ; i++){
		i2c->write(channel, address, &setDuty[i], 2);
	}/**/
}

uint8_t pca9634::bitSet(int v, int setbit)
{
	v |= 1 << setbit;
	return v;
}

void pca9634::pinType(uint8_t pinMode)
{
	uint8_t regValue = 0;
	if (pinMode >= 0 && pinMode < 4){
    	regValue = bitSet(regValue, (pinMode*2));
    	regValue = bitSet(regValue, (pinMode*2+1));
    	uint8_t setOut1[2] = {LEDOUT0, regValue};
    	for (int i = 0 ; i<2 ; i++){
			i2c->write(channel, address, &setOut1[i], 2);
		}
		uint8_t setOut2[2] = {LEDOUT1, 0x00};
		for (int i = 0 ; i<2 ; i++){
			i2c->write(channel, address, &setOut2[i], 2);
		}
  	}else if (pinMode >= 4 && pinMode <= 7){
    	pinMode -= 4;
    	regValue = bitSet(regValue, (pinMode*2));
    	regValue = bitSet(regValue, (pinMode*2+1));
		uint8_t setOut1[2] = {LEDOUT1, regValue};
    	for (int i = 0 ; i<2 ; i++){
			i2c->write(channel, address, &setOut1[i], 2);
		}
		uint8_t setOut2[2] = {LEDOUT0, 0x00};
		for (int i = 0 ; i < 2 ; i++){
			i2c->write(channel, address, &setOut2[i], 2);
		}
  	}else if (pinMode == 8){
		for (int i = 0 ; i<2 ; i++){ // Set LEDOUT0: LDRAll 10
			i2c->write(channel, address, &setPWMALL[i], 2);
		}
		for (int i = 0 ; i<2 ; i++){ // Set LEDOUT1: LDRAll 10
			i2c->write(channel, address, &setPWMALL2[i], 2);
		}
	}else if (pinMode == 9){
		for (int i = 0 ; i<2 ; i++){ // Set LEDOUT0: LDRAll 10
			i2c->write(channel, address, &setModeAllON[i], 2);
		}
		for (int i = 0 ; i<2 ; i++){ // Set LEDOUT1: LDRAll 10
			i2c->write(channel, address, &setModeAllON2[i], 2);
		}
	}else if (pinMode == 10){
		for (int i = 0 ; i<2 ; i++){ // Set LEDOUT0: LDRAll 10
			i2c->write(channel, address, &ModeAllOff[i], 2);
		}
		for (int i = 0 ; i<2 ; i++){ // Set LEDOUT1: LDRAll 10
			i2c->write(channel, address, &ModeAllOff2[i], 2);
		}
	}
}

#endif