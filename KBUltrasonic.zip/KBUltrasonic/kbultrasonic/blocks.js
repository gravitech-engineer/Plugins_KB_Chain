Blockly.Blocks['KBUltrasonic_Readdistance3'] = {
    init: function() {
        this.appendDummyInput()
            .appendField(Blockly.Msg.Read_Ultrasonic_Distance);
        this.setOutput(true, null);
        this.setColour(200);
    this.setTooltip("");
    this.setHelpUrl("");
    }
};